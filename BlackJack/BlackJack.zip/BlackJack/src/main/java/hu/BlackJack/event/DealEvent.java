package hu.BlackJack.event;

public class DealEvent {
}
