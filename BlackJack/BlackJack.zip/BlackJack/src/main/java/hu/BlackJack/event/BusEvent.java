package hu.BlackJack.event;

public class BusEvent {
}
