package hu.BlackJack.service;

import hu.BlackJack.config.db.BlackJack;
import org.springframework.stereotype.Service;

@Service
public class DivisionEvent {
    private BlackJack drawnSheet;
}
