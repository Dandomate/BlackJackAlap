package hu.BlackJack.event;

import hu.BlackJack.config.db.Player;

public class StartEvent {

    private Player money;

    public void setMoney(Player money) {
        this.money= money;
    }
}
