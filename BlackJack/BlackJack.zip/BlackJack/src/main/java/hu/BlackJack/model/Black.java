package hu.BlackJack.model;

public class Black {
}
