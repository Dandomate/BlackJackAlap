package hu.BlackJack.model.impl;

public class BlackImpl {

}
