package hu.BlackJack.config;

public class BlackJackCostumer {

}
