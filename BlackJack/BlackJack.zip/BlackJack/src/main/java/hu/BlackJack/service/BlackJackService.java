package hu.BlackJack.service;

import hu.BlackJack.config.db.BlackJack;
import hu.BlackJack.config.db.Player;
import org.springframework.stereotype.Service;

@Service
public class BlackJackService {
    private Player player;
    private BlackJack sheetOne;
    private BlackJack sheetTwo;

}
