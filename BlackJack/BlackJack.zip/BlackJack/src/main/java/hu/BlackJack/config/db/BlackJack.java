package hu.BlackJack.config.db;

public class BlackJack {
    private String sheetOne;
    private String sheetTwo;
    private String drawnSheet;

    public String getSheetOne() {
        return sheetOne;
    }

    public void setSheetOne(String sheetOne) {
        this.sheetOne = sheetOne;
    }

    public String getSheetTwo() {
        return sheetTwo;
    }

    public void setSheetTwo(String sheetTwo) {
        this.sheetTwo = sheetTwo;
    }

    public String getDrawnSheet() {
        return drawnSheet;
    }

    public void setDrawnSheet(String drawnSheet) {
        this.drawnSheet = drawnSheet;
    }
}

